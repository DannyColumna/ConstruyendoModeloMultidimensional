# TareaAnalisisMultidimensional

Incluye tanto archivos de word como los Scripts utilizados en SQL Server Management Studio con primer examen parcial del curso de Análisis Multidimensional, se realizó el 100% del examen.
