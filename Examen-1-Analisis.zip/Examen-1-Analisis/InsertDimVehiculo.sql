USE [ExamenAnalisis]
GO

INSERT INTO [dbo].[DimVehiculo]
           ([IDVehiculo]
           ,[NombreTipoVehiculo]
           ,[NombreFabricante]
           ,[NombrePais]
           ,[AbreviaturaPais]
           ,[NombreRegion]
           ,[NombreContinente]
           ,[AnoFabricacion])

           (select v.IDVehiculo, tv.Descripcion as 'Tipo Vehiculo', f.NombreFabricante, p.NombrePais, p.AbreviaturaPais,
r.Descripcion as 'Region', c.Descripcion as 'Continente', v.Ano
from Vehiculo v, TipoVehiculo tv, Fabricante f, Pais p, RegionContinente r, Continente c
where tv.IDTipoVehiculo = v.IDTipoVehiculo and v.IDFabricante = f.IDFabricante and f.IDPais = p.IDPais
and p.IDRegionContinente = r.IDRegionContinente and c.IDContinente = r.IDContinente)
GO


