USE [ExamenAnalisis]
GO

INSERT INTO [dbo].[DimParqueo]
           ([IDParqueo]
           ,[NombreProvincia]
           ,[NombreCanton]
           ,[NombreDistrito])

select par.IDParqueo as 'ID Parqueo', prov.Descripcion as 'Nombre Provincia', 
can.Descripcion as 'Nombre Canton',  dis.Descripcion as 'Nombre Distrito'
from Canton can, Distrito dis, Provincia prov, Parqueo par
where dis.ConsecutivoDistrito = par.ConsecutivoDistrito and dis.IDCanton = can.IDCanton 
and dis.IDProvincia = prov.IDProvincia and can.IDProvincia = prov.IDProvincia
GO


